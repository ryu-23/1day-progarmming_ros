#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <QMainWindow>
#include <QtSerialPort/QSerialPort>
#include <qserialportinfo.h>
#include <QDebug>
#include <QMessageBox>
#include <QButtonGroup>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clicked(void);
    void on_pushButton_2_clicked(void);
    void sendSpinBoxValue(int value);
     void sendSpinBoxValue2(int value);
    void on_radioButton_clicked(QAbstractButton* button);
    void on_Reset_Button_clicked(void);
    void on_pushButton3_clicked(void);


private:
    Ui::MainWindow *ui;
    QSerialPort *pPort;
    QString portname;
    QButtonGroup *radioGroup;
    int selectedRadioButton;
};

#endif // MAINWINDOW_H
