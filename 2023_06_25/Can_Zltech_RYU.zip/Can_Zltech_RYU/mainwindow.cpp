#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <math.h>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    pPort=new QSerialPort(this);

    radioGroup = new QButtonGroup(this);
    radioGroup->addButton(ui->checkBox);
    radioGroup->addButton(ui->checkBox_2);

    QObject::connect(ui->spinBox, QOverload<int>::of(&QSpinBox::valueChanged), this, &MainWindow::sendSpinBoxValue);
    connect(ui->spinBox_2, QOverload<int>::of(&QSpinBox::valueChanged), this, &MainWindow::sendSpinBoxValue2);

    QObject::connect(ui->Reset_Button, &QPushButton::clicked, this, &MainWindow::on_pushButton3_clicked);
    connect(ui->Stop_button, &QPushButton::clicked, this, &MainWindow::on_Reset_Button_clicked);
    QObject::connect(radioGroup, QOverload<QAbstractButton*>::of(&QButtonGroup::buttonClicked), this, &MainWindow::on_radioButton_clicked);



}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    pPort->setPortName("ttyUSB0");//or ttyACM1, check qDebug Message.
    pPort->setBaudRate(QSerialPort::Baud115200);
    pPort->setDataBits(QSerialPort::Data8);
    pPort->setParity(QSerialPort::NoParity);
    if(!(pPort->open(QIODevice::ReadWrite)))
    qDebug()<<"\n Serial Port Open Error";
    else
    qDebug()<<"\n Serial Port Open Success";

}


void MainWindow::on_pushButton_2_clicked()
{
    pPort->close();
    qDebug()<<"\n Serial Port close close";
}

/*void MainWindow::sendSpinBoxValue(int value)
{
QString in1Value = QString::number(value); // spinBox의 값을 가져옵니다.
ui->INPUT_SEND->setText(in1Value);

QByteArray sendData = in1Value.toUtf8(); // 값을 시리얼 통신을 위한 바이트 배열로 변환합니다.
pPort->write(sendData); // 시리얼 포트를 통해 데이터를 전송합니다.
}*/

void MainWindow::sendSpinBoxValue(int value)
{
    QString strValue;
    if (selectedRadioButton == 1) {
        // radioButton1이 선택된 경우
        QString in1Value = QString::number(value); // spinBox의 값을 가져옵니다.
        ui->INPUT_SEND->setText(in1Value);
        QByteArray sendData = in1Value.toUtf8(); // 값을 시리얼 통신을 위한 바이트 배열로 변환합니다.
        strValue = sendData;
        pPort->write(sendData); // 시리얼 포트를 통해 데이터를 전송합니다.
        qDebug()<<"\n sds";
    }

     qDebug()<< strValue;
}
void MainWindow::sendSpinBoxValue2(int value)
{
    QString strValue;
    if (selectedRadioButton == 2) {
        // radioButton2가 선택된 경우
        QString in2Value = QString::number(value); // spinBox의 값을 가져옵니다.
        ui->INPUT_SEND_2->setText(in2Value);
        QByteArray sendData = in2Value.toUtf8(); // 값을 시리얼 통신을 위한 바이트 배열로 변환합니다.
        pPort->write(sendData); // 시리얼 포트를 통해 데이터를 전송합니다.
        strValue = sendData;
        qDebug()<<"\n FUCKFUCK";
    }

     qDebug()<< strValue;
}



void MainWindow::on_radioButton_clicked(QAbstractButton* button)
{
    if (button == ui->checkBox) {
        // radioButton1이 선택된 경우
        selectedRadioButton = 1;
        qDebug()<<"\n MODE1";

    } else if (button == ui->checkBox_2) {
        // radioButton2가 선택된 경우
        selectedRadioButton = 2;
        qDebug()<<"\n MODE2";
    }
}

void MainWindow::on_Reset_Button_clicked(void)
{
   ui->spinBox->setValue(0);
}

void MainWindow::on_pushButton3_clicked(void)
{
    ui->spinBox_2->setValue(0);
}



